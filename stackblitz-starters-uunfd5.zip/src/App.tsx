import { FC } from 'react';

import './style.css';

export const App: FC<{ name: string }> = ({ name }) => {
  return (
    <div>
      <div className="Header"></div>
      <h1>StudyBuddy</h1>
      <h2>Create an Account To Get Started </h2>

      <div className="Button"><b>Get Started</b></div>
    </div>
  );
};
